# CarePoint — Hospital Appointment System (DBMS Mini Project)

A responsive hospital appointment booking **front-end demo** built with HTML, CSS and JavaScript, plus a relational MySQL schema for your DBMS project.

## What works in the Netlify demo
- Responsive landing page and sample doctor cards
- Appointment form with basic validation
- Appointment list, delete and clear-demo-data actions
- Browser `localStorage` keeps demo appointments on the same browser/device

## Important limitation
Netlify static hosting does not run this MySQL database. The deployed form is a demo and **does not send real bookings to a hospital or save records to MySQL**. Browser storage is local to that browser/device and is not suitable for real patient information. To make a real multi-user website, connect a backend/API and hosted database (or use a suitable serverless database service) and add authentication/security.

## Deploy on Netlify (free manual deploy)
1. Extract `hospital_appointment_netlify.zip` on your computer.
2. Open https://app.netlify.com/drop in your browser and sign in to Netlify.
3. Drag the **extracted folder** named `hospital_appointment_netlify` onto the drop area. If Netlify rejects the folder, open it and drag the folder containing `index.html`, `style.css`, and `script.js`.
4. Wait for deployment to finish. Netlify will show a URL similar to `https://your-site-name.netlify.app`.
5. Open that URL to test the live demo. You can change the site name in Netlify's site settings if the name is available.

## Run locally
Double-click `index.html`, or use the VS Code Live Server extension.

## MySQL Workbench
1. Open MySQL Workbench and connect to your MySQL server.
2. Open `database.sql`.
3. Execute the script. It creates `hospital_appointment_db`, plus `patients`, `doctors`, and `appointments` tables.
4. The SQL schema is provided for the DBMS project/report. It is not connected to the Netlify demo.

## Suggested project description
**Title:** Hospital Appointment Management System  
**Objective:** To manage patient details, doctor specializations, and appointment schedules using a relational database.  
**Entities:** Patients, Doctors, Appointments.  
**Relationship:** One patient can have many appointments; one doctor can have many appointments. A unique constraint prevents a doctor from being booked for the same date/time twice.

## Suggested future improvements
- Backend API (for example, Node.js/Express)
- Connect to MySQL on a server, not directly from browser code
- Patient/admin login, role-based access, server-side validation
- Appointment status management and secure data handling
