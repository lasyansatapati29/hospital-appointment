const doctors = [
  {name:"Dr. Aanya Rao", specialty:"General Physician", experience:"8 years experience", icon:"🩺", description:"Primary care, routine checkups and everyday health concerns."},
  {name:"Dr. Rohan Mehta", specialty:"Cardiologist", experience:"12 years experience", icon:"💙", description:"Heart health consultations and preventive cardiac care."},
  {name:"Dr. Meera Iyer", specialty:"Pediatrician", experience:"10 years experience", icon:"🧸", description:"Compassionate care for infants, children and growing families."}
];

const STORAGE_KEY = "carepoint_demo_appointments";
const doctorGrid = document.getElementById("doctorGrid");
const doctorSelect = document.getElementById("doctorSelect");
const form = document.getElementById("appointmentForm");
const formMessage = document.getElementById("formMessage");
const appointmentsBody = document.getElementById("appointmentsBody");
const appointmentCount = document.getElementById("appointmentCount");
const dateInput = document.getElementById("appointmentDate");

function localDateString(date = new Date()) {
  const offset = date.getTimezoneOffset();
  return new Date(date.getTime() - offset * 60000).toISOString().slice(0, 10);
}
dateInput.min = localDateString();

doctors.forEach((doctor, index) => {
  const option = document.createElement("option");
  option.value = doctor.name;
  option.textContent = `${doctor.name} — ${doctor.specialty}`;
  doctorSelect.appendChild(option);

  const card = document.createElement("article");
  card.className = "doctor-card";
  card.innerHTML = `
    <div class="doctor-avatar" aria-hidden="true">${doctor.icon}</div>
    <h3>${doctor.name}</h3>
    <div class="specialty">${doctor.specialty}</div>
    <p>${doctor.description}</p>
    <div class="doctor-meta"><span>${doctor.experience}</span><strong>Available</strong></div>
    <button class="doctor-book" type="button" data-doctor="${index}">Book with doctor →</button>`;
  doctorGrid.appendChild(card);
});
doctorGrid.addEventListener("click", (event) => {
  const button = event.target.closest("[data-doctor]");
  if (!button) return;
  doctorSelect.value = doctors[Number(button.dataset.doctor)].name;
  document.getElementById("book").scrollIntoView({behavior:"smooth"});
});

function getAppointments() {
  try {
    const saved = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]");
    return Array.isArray(saved) ? saved : [];
  } catch {
    return [];
  }
}
function saveAppointments(items) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
}
function escapeHTML(value) {
  return String(value ?? "").replace(/[&<>"']/g, char => ({
    "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;"
  })[char]);
}
function displayDate(dateString) {
  const date = new Date(`${dateString}T12:00:00`);
  return date.toLocaleDateString(undefined, {day:"2-digit", month:"short", year:"numeric"});
}
function renderAppointments() {
  const items = getAppointments();
  appointmentCount.textContent = `${items.length} appointment${items.length === 1 ? "" : "s"}`;
  if (!items.length) {
    appointmentsBody.innerHTML = '<tr><td colspan="6" class="empty-state">No appointments yet. Use the form above to add one.</td></tr>';
    return;
  }
  appointmentsBody.innerHTML = items.map(item => `
    <tr>
      <td>${escapeHTML(item.patientName)}<br><small>${escapeHTML(item.phone)}</small></td>
      <td>${escapeHTML(item.doctor)}</td>
      <td>${escapeHTML(displayDate(item.date))}<br><small>${escapeHTML(item.time)}</small></td>
      <td>${escapeHTML(item.reason || "—")}</td>
      <td><span class="status">Demo booked</span></td>
      <td><button class="delete-button" type="button" data-delete="${escapeHTML(item.id)}" aria-label="Delete appointment">×</button></td>
    </tr>`).join("");
}
form.addEventListener("submit", (event) => {
  event.preventDefault();
  formMessage.textContent = "";
  formMessage.className = "form-message";
  const data = new FormData(form);
  const date = String(data.get("date"));
  if (date < localDateString()) {
    formMessage.textContent = "Please choose today or a future date.";
    formMessage.classList.add("error");
    return;
  }
  const item = {
    id: `${Date.now()}-${Math.random().toString(16).slice(2)}`,
    patientName: String(data.get("patientName")).trim(),
    phone: String(data.get("phone")).trim(),
    email: String(data.get("email")).trim(),
    doctor: String(data.get("doctor")),
    date,
    time: String(data.get("time")),
    reason: String(data.get("reason")).trim()
  };
  try {
    const items = getAppointments();
    items.unshift(item);
    saveAppointments(items);
    renderAppointments();
    form.reset();
    dateInput.min = localDateString();
    formMessage.textContent = "Demo appointment saved on this device. No real booking was sent.";
    document.getElementById("appointments").scrollIntoView({behavior:"smooth", block:"start"});
  } catch {
    formMessage.textContent = "Could not save in this browser. Check local storage settings.";
    formMessage.classList.add("error");
  }
});
appointmentsBody.addEventListener("click", (event) => {
  const button = event.target.closest("[data-delete]");
  if (!button) return;
  saveAppointments(getAppointments().filter(item => item.id !== button.dataset.delete));
  renderAppointments();
});
document.getElementById("clearAppointments").addEventListener("click", () => {
  if (!getAppointments().length) return;
  if (confirm("Clear all demo appointments saved in this browser?")) {
    localStorage.removeItem(STORAGE_KEY);
    renderAppointments();
    formMessage.textContent = "Demo appointments cleared.";
  }
});
renderAppointments();
