-- CarePoint Hospital Appointment System
-- MySQL 8.x schema for the DBMS mini project.
-- This schema is separate from the static Netlify demo.
CREATE DATABASE IF NOT EXISTS hospital_appointment_db;
USE hospital_appointment_db;

CREATE TABLE IF NOT EXISTS patients (
  patient_id INT AUTO_INCREMENT PRIMARY KEY,
  full_name VARCHAR(100) NOT NULL,
  phone VARCHAR(20) NOT NULL,
  email VARCHAR(120),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS doctors (
  doctor_id INT AUTO_INCREMENT PRIMARY KEY,
  full_name VARCHAR(100) NOT NULL,
  specialization VARCHAR(80) NOT NULL,
  experience_years TINYINT UNSIGNED DEFAULT 0,
  available BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS appointments (
  appointment_id INT AUTO_INCREMENT PRIMARY KEY,
  patient_id INT NOT NULL,
  doctor_id INT NOT NULL,
  appointment_date DATE NOT NULL,
  appointment_time TIME NOT NULL,
  reason VARCHAR(500),
  status ENUM('Booked','Completed','Cancelled') NOT NULL DEFAULT 'Booked',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_appointment_patient FOREIGN KEY (patient_id)
    REFERENCES patients(patient_id) ON DELETE CASCADE,
  CONSTRAINT fk_appointment_doctor FOREIGN KEY (doctor_id)
    REFERENCES doctors(doctor_id) ON DELETE RESTRICT,
  CONSTRAINT uq_doctor_slot UNIQUE (doctor_id, appointment_date, appointment_time)
);

INSERT INTO doctors (full_name, specialization, experience_years) VALUES
('Dr. Aanya Rao', 'General Physician', 8),
('Dr. Rohan Mehta', 'Cardiologist', 12),
('Dr. Meera Iyer', 'Pediatrician', 10);

-- Example queries for your DBMS report:
-- SELECT a.appointment_id, p.full_name AS patient, d.full_name AS doctor,
--        d.specialization, a.appointment_date, a.appointment_time, a.status
-- FROM appointments a
-- JOIN patients p ON a.patient_id = p.patient_id
-- JOIN doctors d ON a.doctor_id = d.doctor_id
-- ORDER BY a.appointment_date, a.appointment_time;
--
-- SELECT specialization, COUNT(*) AS doctor_count FROM doctors GROUP BY specialization;
-- UPDATE appointments SET status = 'Cancelled' WHERE appointment_id = 1;
